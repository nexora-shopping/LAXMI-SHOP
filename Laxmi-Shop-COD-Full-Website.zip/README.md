# Laxmi Shop — COD E-commerce Starter

This is a real working Node.js + SQLite starter for the requirements discussed.

## Included
- Public storefront
- Boys/Girls/Pants categories
- Product image URL support
- Color + size variants with per-variant stock
- Customer name, phone, full address, city, state, pincode
- COD only (no online payment gateway)
- Owner / Seller / Sales roles
- Seller can add their own products
- Owner/Sales can view orders
- Owner controls order delivery status
- Stock decreases automatically when an order is placed
- Delivery is owned/managed by Laxmi Shop; seller has no delivery action

## Important
The seeded owner credentials come from environment variables:
OWNER_USERNAME=owner
OWNER_PASSWORD=ChangeMe123!

Change them before public launch and set a strong JWT_SECRET.

## Run
1. Install Node.js 18+.
2. Copy `.env.example` to `.env` and change credentials.
3. Run:
   npm install
   npm start
4. Open:
   http://localhost:3000

## Public launch
This app needs a Node.js hosting service/server. Upload the project, set the environment variables, run `npm install` and `npm start`, and connect your domain `laxmishop.com` to that server.

For production, also use HTTPS, backups, rate limiting, secure secrets, and a proper shipping/courier process.
