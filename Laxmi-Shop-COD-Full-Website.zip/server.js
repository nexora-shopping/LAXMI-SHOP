const express = require("express");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const multer = require("multer");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_ME_IN_PRODUCTION";
const OWNER_USERNAME = process.env.OWNER_USERNAME || "owner";
const OWNER_PASSWORD = process.env.OWNER_PASSWORD || "ChangeMe123!";

const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "public", "uploads");
fs.mkdirSync(dataDir, {recursive:true});
fs.mkdirSync(uploadDir, {recursive:true});

const db = new Database(path.join(dataDir, "laxmi.db"));
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('owner','seller','sales')),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  seller_id INTEGER,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  category TEXT NOT NULL,
  price INTEGER NOT NULL,
  image_url TEXT DEFAULT '',
  active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(seller_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS variants(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  color TEXT NOT NULL,
  size TEXT NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  pincode TEXT NOT NULL,
  latitude TEXT DEFAULT '',
  longitude TEXT DEFAULT '',
  payment_method TEXT NOT NULL DEFAULT 'COD',
  status TEXT NOT NULL DEFAULT 'NEW',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS order_items(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  variant_id INTEGER NOT NULL,
  seller_id INTEGER,
  product_name TEXT NOT NULL,
  color TEXT NOT NULL,
  size TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  price INTEGER NOT NULL,
  FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
);
`);

const existingOwner = db.prepare("SELECT id FROM users WHERE username=?").get(OWNER_USERNAME);
if (!existingOwner) {
  db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)")
    .run(OWNER_USERNAME, bcrypt.hashSync(OWNER_PASSWORD, 10), "owner");
  console.log("Owner created:", OWNER_USERNAME, "password from OWNER_PASSWORD");
}

app.use(express.json({limit:"2mb"}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,"public")));

const upload = multer({
  storage: multer.diskStorage({
    destination: (_,__,cb)=>cb(null,uploadDir),
    filename: (_,file,cb)=>{
      const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g,"-");
      cb(null, Date.now()+"-"+safe);
    }
  }),
  limits:{fileSize:5*1024*1024}
});

function auth(req,res,next){
  const token = (req.headers.authorization||"").replace("Bearer ","");
  if(!token) return res.status(401).json({error:"Login required"});
  try { req.user=jwt.verify(token,JWT_SECRET); next(); }
  catch { return res.status(401).json({error:"Invalid or expired login"}); }
}
function roles(...allowed){
  return (req,res,next)=>{
    if(!allowed.includes(req.user.role)) return res.status(403).json({error:"Not allowed"});
    next();
  };
}
function signUser(user){
  return jwt.sign({id:user.id,username:user.username,role:user.role},JWT_SECRET,{expiresIn:"7d"});
}
function cleanProduct(p){
  return {...p, active:!!p.active, variants:db.prepare("SELECT id,color,size,stock FROM variants WHERE product_id=? ORDER BY color,size").all(p.id)};
}

app.post("/api/login",(req,res)=>{
  const {username,password}=req.body;
  const u=db.prepare("SELECT * FROM users WHERE username=?").get(username||"");
  if(!u || !bcrypt.compareSync(password||"",u.password_hash)) return res.status(401).json({error:"Wrong username or password"});
  res.json({token:signUser(u),user:{id:u.id,username:u.username,role:u.role}});
});

app.get("/api/products",(req,res)=>{
  const rows=db.prepare("SELECT p.*,u.username seller_username FROM products p LEFT JOIN users u ON u.id=p.seller_id WHERE p.active=1 ORDER BY p.id DESC").all();
  res.json(rows.map(cleanProduct));
});

app.post("/api/products",auth,roles("owner","seller","sales"),(req,res)=>{
  const {name,description="",category,price,image_url="",variants=[]}=req.body;
  if(!name||!category||!Number.isFinite(Number(price))||!Array.isArray(variants)||!variants.length)
    return res.status(400).json({error:"Name, category, price and at least one size/color variant are required"});
  const tx=db.transaction(()=>{
    const info=db.prepare("INSERT INTO products(seller_id,name,description,category,price,image_url) VALUES(?,?,?,?,?,?)")
      .run(req.user.role==="owner"?null:req.user.id,name,description,category,Number(price),image_url);
    const add=db.prepare("INSERT INTO variants(product_id,color,size,stock) VALUES(?,?,?,?)");
    for(const v of variants){
      if(!v.color||!v.size||Number(v.stock)<0) throw new Error("Invalid variant");
      add.run(info.lastInsertRowid,v.color,v.size,Number(v.stock));
    }
    return info.lastInsertRowid;
  });
  try { res.json({ok:true,id:tx()}); } catch(e){res.status(400).json({error:e.message});}
});

app.post("/api/upload",auth,roles("owner","seller","sales"),upload.single("image"),(req,res)=>{
  if(!req.file) return res.status(400).json({error:"No image"});
  res.json({url:"/uploads/"+req.file.filename});
});

app.get("/api/manage/products",auth,roles("owner","seller","sales"),(req,res)=>{
  let rows;
  if(req.user.role==="owner" || req.user.role==="sales")
    rows=db.prepare("SELECT p.*,u.username seller_username FROM products p LEFT JOIN users u ON u.id=p.seller_id ORDER BY p.id DESC").all();
  else
    rows=db.prepare("SELECT p.*,u.username seller_username FROM products p LEFT JOIN users u ON u.id=p.seller_id WHERE p.seller_id=? ORDER BY p.id DESC").all(req.user.id);
  res.json(rows.map(cleanProduct));
});

app.post("/api/users",auth,roles("owner"),(req,res)=>{
  const {username,password,role}=req.body;
  if(!username||!password||!["seller","sales"].includes(role)) return res.status(400).json({error:"Only seller/sales accounts can be created here"});
  try{
    const info=db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)").run(username,bcrypt.hashSync(password,10),role);
    res.json({ok:true,id:info.lastInsertRowid});
  }catch(e){res.status(400).json({error:"Username already exists"});}
});

app.get("/api/users",auth,roles("owner"),(req,res)=>{
  res.json(db.prepare("SELECT id,username,role,created_at FROM users ORDER BY id DESC").all());
});

app.post("/api/orders",(req,res)=>{
  const {customer_name,phone,address,city,state,pincode,latitude="",longitude="",items}=req.body;
  if(!customer_name||!phone||!address||!city||!state||!pincode||!Array.isArray(items)||!items.length)
    return res.status(400).json({error:"Complete customer address and cart are required"});
  const tx=db.transaction(()=>{
    const order=db.prepare(`INSERT INTO orders(customer_name,phone,address,city,state,pincode,latitude,longitude,payment_method)
      VALUES(?,?,?,?,?,?,?,?, 'COD')`).run(customer_name,phone,address,city,state,pincode,latitude,longitude);
    const addItem=db.prepare(`INSERT INTO order_items(order_id,product_id,variant_id,seller_id,product_name,color,size,quantity,price)
      VALUES(?,?,?,?,?,?,?,?,?)`);
    const reduce=db.prepare("UPDATE variants SET stock=stock-? WHERE id=? AND stock>=?");
    for(const item of items){
      const v=db.prepare(`SELECT v.*,p.name,p.price,p.seller_id FROM variants v JOIN products p ON p.id=v.product_id
        WHERE v.id=? AND p.active=1`).get(item.variant_id);
      if(!v) throw new Error("Product variant not found");
      const qty=Math.max(1,Number(item.quantity||1));
      const r=reduce.run(qty,v.id,qty);
      if(!r.changes) throw new Error(`Out of stock: ${v.name} / ${v.color} / ${v.size}`);
      addItem.run(order.lastInsertRowid,v.product_id,v.id,v.seller_id,v.name,v.color,v.size,qty,v.price);
    }
    return order.lastInsertRowid;
  });
  try { res.json({ok:true,order_id:tx(),payment:"COD"}); }
  catch(e){res.status(400).json({error:e.message});}
});

app.get("/api/orders",auth,roles("owner","sales"),(req,res)=>{
  const orders=db.prepare("SELECT * FROM orders ORDER BY id DESC").all();
  const itemStmt=db.prepare("SELECT * FROM order_items WHERE order_id=?");
  res.json(orders.map(o=>({...o,items:itemStmt.all(o.id)})));
});

app.patch("/api/orders/:id",auth,roles("owner"),(req,res)=>{
  const allowed=["NEW","CONFIRMED","PACKED","SHIPPED","OUT_FOR_DELIVERY","DELIVERED","CANCELLED"];
  if(!allowed.includes(req.body.status)) return res.status(400).json({error:"Invalid status"});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id);
  res.json({ok:true});
});

app.get("/api/health",(req,res)=>res.json({ok:true,service:"Laxmi Shop",payment:"COD"}));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

app.listen(PORT,()=>console.log(`Laxmi Shop running on http://localhost:${PORT}`));
